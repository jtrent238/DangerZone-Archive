package dangerzone;


/*
 * This code is copyright Richard H. Clark, TheyCallMeDanger, OreSpawn, 2015-2021.
 * You may use this code for reference for modding the DangerZone game program,
 * and are perfectly welcome to cut'n'paste portions for your mod as well.
 * DO NOT USE THIS CODE FOR ANY PURPOSE OTHER THAN MODDING FOR THE DANGERZONE GAME.
 * DO NOT REDISTRIBUTE THIS CODE. 
 * 
 *
 * 
 * WARNING: There are bugs. Big bugs. Little bugs. Every size in-between bugs.
 * This code is NOT suitable for use in anything other than this particular game. 
 * NO GUARANTEES of any sort are given, either express or implied, and Richard H. Clark, 
 * TheyCallMeDanger, OreSpawn are not responsible for any damages, direct, indirect, or otherwise. 
 * You should have made backups. It's your own fault for not making them.
 * 
 * NO ATTEMPT AT SECURITY IS MADE. This code is USE AT YOUR OWN RISK.
 * Regardless of what you may think, the reality is, that the moment you 
 * connected your computer to the Internet, Uncle Sam, among many others, hacked it.
 * DO NOT KEEP VALUABLE INFORMATION ON INTERNET-CONNECTED COMPUTERS.
 * Or your phone...
 * 
 */
public class Effects {
	public static final int SPEED = 1;
	public static final int SLOWNESS = 2;
	public static final int STRENGTH = 3;
	public static final int WEAKNESS = 4;
	public static final int REGENERATION = 5;
	public static final int POISON = 6;
	public static final int CONFUSION = 7;
	public static final int MORPH = 8;
	
	public int effect;
	public float amplitude;
	public int duration; //TENTHS of a second
	public int duration_counter;
	
	public Effects(){	
	}
	
	public Effects(int theeffect, float theamplitude, int theduration){
		effect = theeffect;
		amplitude = theamplitude;
		duration = theduration;
	}
	
/*	TODO
	//Only called on the CLIENT, when the entity is being displayed
	public void displayEffect(Entity e){
		
	}
	
	//Only called on the SERVER, in the entity update loop.
	public void doEffect(Entity e){
		
	}
*/
}
