package demomodcode;

import dangerzone.blocks.BlockStone;


public class DemoBlock extends BlockStone {

	DemoBlock(String n, String txt, int hardness) {
		super(n, txt, hardness);
		// TODO Auto-generated constructor stub
	}

}
