package dangerzone.entities;

/*
 * A little space in the entity to save some render/model state
 */
public class RenderInfo {
	public int ri1;
	public int ri2;
	public int ri3;
	public int ri4;
	public float rf1;
	public float rf2;
	public float rf3;
	public float rf4;
}
