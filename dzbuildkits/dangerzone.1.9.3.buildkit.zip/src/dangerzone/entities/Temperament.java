package dangerzone.entities;

public class Temperament {
	
	public static final int NONE = 0;	
	public static final int HOSTILE = 1;
	public static final int PASSIVE = 2;
	public static final int PASSIVE_AGGRESSIVE = 3;

}
