package dangerzone;
/*
 * This code is copyright Richard H. Clark, TheyCallMeDanger, OreSpawn, 2015-2021.
 * You may use this code for reference for modding the DangerZone game program,
 * and are perfectly welcome to cut'n'paste portions for your mod as well.
 * DO NOT USE THIS CODE FOR ANY PURPOSE OTHER THAN MODDING FOR THE DANGERZONE GAME.
 * DO NOT REDISTRIBUTE THIS CODE. 
 * 
 *
 * 
 * WARNING: There are bugs. Big bugs. Little bugs. Every size in-between bugs.
 * This code is NOT suitable for use in anything other than this particular game. 
 * NO GUARANTEES of any sort are given, either express or implied, and Richard H. Clark, 
 * TheyCallMeDanger, OreSpawn are not responsible for any damages, direct, indirect, or otherwise. 
 * You should have made backups. It's your own fault for not making them.
 * 
 * NO ATTEMPT AT SECURITY IS MADE. This code is USE AT YOUR OWN RISK.
 * Regardless of what you may think, the reality is, that the moment you 
 * connected your computer to the Internet, Uncle Sam, among many others, hacked it.
 * DO NOT KEEP VALUABLE INFORMATION ON INTERNET-CONNECTED COMPUTERS.
 * Or your phone...
 * 
 */


public class CustomPacket {
	
	public int packetID = 0;
	public String uniquename = null;
	
	
	public CustomPacket(){
		uniquename = "DangerZone:CustomPacketBaseClass";
		//make sure you do this in your constructor after setting your name!
		//this.packetID = CustomPackets.getIDByName(uniquename);
	}
	
	//Be careful to ALWAYS receive every last byte of your packets under ALL conditions!
	//These are STREAMS, and if you leave anything on either stream, it will hose everything else up!
	//Send a whole "packet", receive a whole "packet".
	
	//The send side can actually be called from just about anywhere.
	//The real reason for the interface is the RECEIVE side. The packet receiver needs to know who to call!
	//The send side is included here for your convenience. It is not actually called by the game.
	
	//See the CHEST interface for a nice simple example! :)
	
	//To make your own packet type, just make an object that inherits from this class, and register it.
	//Override the functions you need. Ignore the ones you don't.
	
	//SEND side
	//example Sends just the packet ID. Empty packet.
	//There is only one connection up to the server.
	public void messageToServer(){
		NetworkOutputBuffer os = DangerZone.server_connection.getOutputStream();
		if(os == null)return;
		os.writeInt(this.packetID);
		
		//your packet data gets sent here!
		
		DangerZone.server_connection.releaseOutputStream();
	}
	
	//RECEIVE side
	public void messageFromServer(NetworkInputBuffer is){
		//int packettype = is.readInt(); -- ALREADY DONE FOR YOU! Same as this.packetID.
		//receive the rest of your packet here. ALL of it.
	}
	
	//SEND side
	//example Sends just the packet ID. Empty packet.
	//Each player has their own connection back to their respective client!
	public void messageToClient(Player p){
		NetworkOutputBuffer os = p.server_thread.getOutputStream();
		if(os == null)return;
		os.writeInt(this.packetID);
		
		//your packet data gets sent here!!!
			
		p.server_thread.releaseOutputStream();
	}
	
	//RECEIVE side
	public void messageFromClient(Player p, NetworkInputBuffer is){
		//int packettype = is.readInt(); -- ALREADY DONE FOR YOU! Same as this.packetID.
		//receive the rest of your packet here. ALL of it.
	}

}
