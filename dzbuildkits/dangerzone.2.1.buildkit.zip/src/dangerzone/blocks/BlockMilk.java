package dangerzone.blocks;

import java.util.List;
import java.util.ListIterator;

import dangerzone.DangerZone;
import dangerzone.Effects;
import dangerzone.Player;
import dangerzone.World;
import dangerzone.entities.Entity;
import dangerzone.entities.EntityFire;


/*
 * This code is copyright Richard H. Clark, TheyCallMeDanger, OreSpawn, 2015-2021.
 * You may use this code for reference for modding the DangerZone game program,
 * and are perfectly welcome to cut'n'paste portions for your mod as well.
 * DO NOT USE THIS CODE FOR ANY PURPOSE OTHER THAN MODDING FOR THE DANGERZONE GAME.
 * DO NOT REDISTRIBUTE THIS CODE. 
 * 
 *
 * 
 * WARNING: There are bugs. Big bugs. Little bugs. Every size in-between bugs.
 * This code is NOT suitable for use in anything other than this particular game. 
 * NO GUARANTEES of any sort are given, either express or implied, and Richard H. Clark, 
 * TheyCallMeDanger, OreSpawn are not responsible for any damages, direct, indirect, or otherwise. 
 * You should have made backups. It's your own fault for not making them.
 * 
 * NO ATTEMPT AT SECURITY IS MADE. This code is USE AT YOUR OWN RISK.
 * Regardless of what you may think, the reality is, that the moment you 
 * connected your computer to the Internet, Uncle Sam, among many others, hacked it.
 * DO NOT KEEP VALUABLE INFORMATION ON INTERNET-CONNECTED COMPUTERS.
 * Or your phone...
 * 
 */

public class BlockMilk extends BlockLiquidActive {
	
	//static_partner is set in post_load_processing!
	
	public BlockMilk(String n, String txt) {
		super(n, txt);
	}
	
	public void tickMe(World w, int d, int x, int y, int z){	
		if(w.isServer){
			List<Entity> nearby_list = null;
			ListIterator<Entity> li;
			Entity e = null;
			//Put out some fire!						
			nearby_list = DangerZone.server.entityManager.findALLEntitiesInRange(4.0f, d, (double)x+0.5f, (double)y+0.5f, (double)z+0.5f);
			if(nearby_list != null){
				if(!nearby_list.isEmpty()){
					li = nearby_list.listIterator();
					while(li.hasNext()){
						e = (Entity)li.next();
						if(e instanceof EntityFire){
							double d1, d2, d3;
							d1 = (e.posx) - ((double)x+0.5f);
							d2 = (e.posy+0.5f) - ((double)y+0.5f);
							d3 = (e.posz) - ((double)z+0.5f);
							float dist = (float)Math.sqrt((d1*d1)+(d2*d2)+(d3*d3));
							if(dist < 3){
								e.deadflag = true;
							}
						}
					}
				}
			}
		}
		super.tickMe(w, d, x, y, z);
	}
	
	public void entityInLiquid(Entity e){
		e.setOnFire(0);
		if(e instanceof Player){
			e.removeAllEffects();			
			Effects ef = new Effects();
			ef.effect = Effects.REGENERATION;
			ef.amplitude = 0.1f;
			ef.duration = 100;			
			e.addEffect(ef);
		}else{
			e.heal(0.1f);
		}
	}
	

}
