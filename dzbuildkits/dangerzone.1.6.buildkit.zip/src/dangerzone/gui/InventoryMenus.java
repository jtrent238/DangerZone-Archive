package dangerzone.gui;

public class InventoryMenus {
	public static int GENERIC = 0; //block/item
	public static int SPAWNEGG = 1; //item
	public static int SPAWNER = 2; //block
	public static int TROPHY = 3; //item
	public static int HARDWARE = 4; //item

}
